import Layout from "@/components/Layout";
import { useScrollReveal } from "@/hooks/useScrollReveal";
import stylist1 from "@/assets/stylist-1.jpg";
import stylist2 from "@/assets/stylist-2.jpg";
import stylist3 from "@/assets/stylist-3.jpg";
import { Instagram, Linkedin, Award, Users, Clock, Star } from "lucide-react";

const team = [
  {
    name: "Arun Krishnan",
    role: "Master Barber & Founder",
    expertise: "Classic Cuts • Beard Sculpting • Hot Towel Shaves",
    bio: "With over 15 years of experience, Arun founded Mr Black Salon with a vision to bring world-class grooming to Chennai.",
    image: stylist1,
    instagram: "#",
    linkedin: "#",
  },
  {
    name: "Priya Sharma",
    role: "Senior Stylist",
    expertise: "Color Expert • Transformations • Bridal Styling",
    bio: "Priya brings creativity and precision to every transformation, specializing in color techniques and special occasion styling.",
    image: stylist2,
    instagram: "#",
    linkedin: "#",
  },
  {
    name: "Rohit Nair",
    role: "Creative Director",
    expertise: "Modern Fades • Editorial Looks • Trend Setting",
    bio: "Rohit stays ahead of global trends, bringing cutting-edge styles and techniques to our clients.",
    image: stylist3,
    instagram: "#",
    linkedin: "#",
  },
];

const values = [
  {
    icon: Award,
    title: "Excellence",
    description: "We never compromise on quality. Every cut, every shave, every detail is executed with precision.",
  },
  {
    icon: Users,
    title: "Personalization",
    description: "Your style is unique. We listen, understand, and craft looks that enhance your individuality.",
  },
  {
    icon: Clock,
    title: "Respect",
    description: "Your time is valuable. We honor appointments and ensure every visit is worth your while.",
  },
  {
    icon: Star,
    title: "Experience",
    description: "Beyond a haircut—we offer a sanctuary where you can relax, refresh, and transform.",
  },
];

const About = () => {
  const { ref: storyRef, isVisible: storyVisible } = useScrollReveal();
  const { ref: valuesRef, isVisible: valuesVisible } = useScrollReveal();
  const { ref: teamRef, isVisible: teamVisible } = useScrollReveal();

  return (
    <Layout>
      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-charcoal">
        <div className="container mx-auto px-6 text-center">
          <span className="text-gold text-sm tracking-luxury uppercase mb-4 block">
            Our Story
          </span>
          <h1 className="heading-xl text-ivory mb-6">
            About <span className="text-gold-gradient">Mr Black</span>
          </h1>
          <div className="decorative-line mx-auto" />
        </div>
      </section>

      {/* Story Section */}
      <section ref={storyRef} className="section-padding bg-background">
        <div className="container mx-auto px-6">
          <div
            className={`grid grid-cols-1 lg:grid-cols-2 gap-12 items-center transition-all duration-700 ${
              storyVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
          >
            <div>
              <span className="text-gold text-sm tracking-luxury uppercase mb-4 block">
                Est. 2020
              </span>
              <h2 className="heading-lg text-charcoal mb-6">
                Where Craft Meets Character
              </h2>
              <div className="space-y-4 text-muted-foreground leading-relaxed">
                <p>
                  Mr Black Salon was born from a simple belief: grooming is an art form, and every 
                  gentleman deserves access to master craftsmen who treat their work as such.
                </p>
                <p>
                  Founded in the heart of Chennai, we've built more than a salon—we've created a 
                  sanctuary. A place where the rush of the city fades, replaced by the careful 
                  attention of skilled hands, the warmth of hot towels, and the quiet confidence 
                  that comes from looking your absolute best.
                </p>
                <p>
                  Our team combines traditional barbering techniques passed down through generations 
                  with contemporary styling innovations. The result? Timeless elegance with a modern edge.
                </p>
              </div>
            </div>
            <div className="relative">
              <div className="aspect-square bg-charcoal p-8">
                <img
                  src={stylist1}
                  alt="Mr Black Salon interior"
                  className="w-full h-full object-cover"
                />
              </div>
              {/* Decorative frame */}
              <div className="absolute -bottom-4 -right-4 w-full h-full border-2 border-gold -z-10" />
            </div>
          </div>
        </div>
      </section>

      {/* Values Section */}
      <section ref={valuesRef} className="section-padding bg-charcoal">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <span className="text-gold text-sm tracking-luxury uppercase mb-4 block">
              What We Stand For
            </span>
            <h2 className="heading-lg text-ivory mb-4">Our Values</h2>
            <div className="decorative-line mx-auto" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div
                key={value.title}
                className={`text-center p-6 transition-all duration-700 ${
                  valuesVisible
                    ? "opacity-100 translate-y-0"
                    : "opacity-0 translate-y-8"
                }`}
                style={{ transitionDelay: `${index * 100}ms` }}
              >
                <div className="inline-flex items-center justify-center w-16 h-16 border border-gold mb-6">
                  <value.icon className="w-7 h-7 text-gold" />
                </div>
                <h3 className="font-heading text-xl text-ivory mb-3">{value.title}</h3>
                <p className="text-ivory/60 text-sm leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section ref={teamRef} className="section-padding bg-background">
        <div className="container mx-auto px-6">
          <div className="text-center mb-16">
            <span className="text-gold text-sm tracking-luxury uppercase mb-4 block">
              The Artists
            </span>
            <h2 className="heading-lg text-charcoal mb-4">Meet Our Team</h2>
            <div className="decorative-line mx-auto" />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {team.map((member, index) => (
              <div
                key={member.name}
                className={`group transition-all duration-700 ${
                  teamVisible
                    ? "opacity-100 translate-y-0"
                    : "opacity-0 translate-y-8"
                }`}
                style={{ transitionDelay: `${index * 150}ms` }}
              >
                <div className="relative aspect-[3/4] overflow-hidden mb-6">
                  <img
                    src={member.image}
                    alt={member.name}
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-charcoal/80 via-transparent to-transparent" />
                  
                  {/* Social Links */}
                  <div className="absolute bottom-4 left-4 flex gap-2">
                    <a
                      href={member.instagram}
                      className="w-10 h-10 bg-charcoal/80 border border-gold/50 flex items-center justify-center hover:bg-gold transition-colors group/icon"
                      aria-label={`${member.name}'s Instagram`}
                    >
                      <Instagram className="w-4 h-4 text-ivory group-hover/icon:text-charcoal" />
                    </a>
                    <a
                      href={member.linkedin}
                      className="w-10 h-10 bg-charcoal/80 border border-gold/50 flex items-center justify-center hover:bg-gold transition-colors group/icon"
                      aria-label={`${member.name}'s LinkedIn`}
                    >
                      <Linkedin className="w-4 h-4 text-ivory group-hover/icon:text-charcoal" />
                    </a>
                  </div>
                </div>

                <h3 className="font-heading text-xl text-charcoal mb-1">{member.name}</h3>
                <p className="text-gold text-sm tracking-wider uppercase mb-3">{member.role}</p>
                <p className="text-muted-foreground text-sm leading-relaxed mb-2">{member.bio}</p>
                <p className="text-charcoal/60 text-xs">{member.expertise}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default About;
