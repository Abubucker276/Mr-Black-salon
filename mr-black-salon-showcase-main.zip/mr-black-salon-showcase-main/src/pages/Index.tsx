import Layout from "@/components/Layout";
import Hero from "@/components/Hero";
import SignatureServices from "@/components/SignatureServices";
import BeforeAfterSlider from "@/components/BeforeAfterSlider";
import Testimonials from "@/components/Testimonials";
import TeamSpotlight from "@/components/TeamSpotlight";
import MembershipCTA from "@/components/MembershipCTA";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

const Index = () => {
  return (
    <Layout>
      {/* Hero Section */}
      <Hero />

      {/* Signature Services */}
      <SignatureServices />

      {/* Before/After Slider */}
      <BeforeAfterSlider />

      {/* Testimonials */}
      <Testimonials />

      {/* Team Spotlight */}
      <TeamSpotlight />

      {/* Membership & Gift Cards CTA */}
      <MembershipCTA />

      {/* Final CTA */}
      <section className="py-24 bg-charcoal text-center relative overflow-hidden">
        {/* Decorative Elements */}
        <div className="absolute inset-0 opacity-5">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] border border-gold rounded-full" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] border border-gold rounded-full" />
        </div>

        <div className="container mx-auto px-6 relative z-10">
          <span className="text-gold text-sm tracking-luxury uppercase mb-4 block">
            Ready for a transformation?
          </span>
          <h2 className="heading-lg text-ivory mb-6 max-w-3xl mx-auto">
            Book Your Premium Experience Today
          </h2>
          <p className="text-ivory/60 max-w-xl mx-auto mb-8">
            Step into a world where every detail matters. Let our master stylists craft your signature look.
          </p>
          <Link
            to="/booking"
            className="btn-gold inline-flex items-center gap-3 group"
          >
            Book Appointment
            <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
          </Link>
        </div>
      </section>
    </Layout>
  );
};

export default Index;
