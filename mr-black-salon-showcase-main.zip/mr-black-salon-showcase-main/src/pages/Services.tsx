import Layout from "@/components/Layout";
import { Link } from "react-router-dom";
import { useScrollReveal } from "@/hooks/useScrollReveal";
import { Scissors, Sparkles, Crown, Palette, Star, Clock } from "lucide-react";

const serviceCategories = [
  {
    title: "Hair Services",
    icon: Scissors,
    services: [
      { name: "Signature Haircut", price: "₹150", duration: "45 min", description: "Precision cut tailored to your style and face shape" },
      { name: "Classic Haircut", price: "₹200", duration: "30 min", description: "Traditional cut with expert finishing" },
      { name: "Kids Haircut", price: "₹100", duration: "30 min", description: "Gentle styling for our younger guests (under 12)" },
      { name: "Hair Styling", price: "₹300", duration: "20 min", description: "Professional styling for any occasion" },
      { name: "Hair Wash & Style", price: "₹400", duration: "30 min", description: "Relaxing wash with premium products and styling" },
    ],
  },
  {
    title: "Beard & Shave",
    icon: Crown,
    services: [
      { name: "Royal Shave", price: "₹200", duration: "45 min", description: "Hot towel treatment with premium shave experience" },
      { name: "Beard Trim", price: "₹100", duration: "20 min", description: "Shape and maintain your beard with precision" },
      { name: "Beard Sculpting", price: "₹150", duration: "30 min", description: "Complete beard design and shaping" },
      { name: "Clean Shave", price: "₹100", duration: "30 min", description: "Traditional clean shave with hot towel" },
    ],
  },
  {
    title: "Color Services",
    icon: Palette,
    services: [
      { name: "Global Hair Color", price: "₹1,500", duration: "90 min", description: "Full coverage color transformation" },
      { name: "Highlights", price: "₹2,000", duration: "120 min", description: "Dimensional color with foil highlights" },
      { name: "Grey Blending", price: "₹800", duration: "45 min", description: "Natural-looking grey coverage for men" },
      { name: "Fashion Colors", price: "₹2,500", duration: "120 min", description: "Bold, trendy colors for the adventurous" },
    ],
  },
  {
    title: "Premium Packages",
    icon: Star,
    services: [
      { name: "Executive Package", price: "₹2,500", duration: "90 min", description: "Haircut, beard, facial, and scalp massage" },
      { name: "Groom's Package", price: "₹5,000", duration: "180 min", description: "Complete grooming for your special day" },
      { name: "Refresh & Relax", price: "₹1,800", duration: "60 min", description: "Haircut with scalp massage and facial" },
      { name: "Quick Polish", price: "₹1,200", duration: "45 min", description: "Express haircut and beard maintenance" },
    ],
  },
  {
    title: "Treatments",
    icon: Sparkles,
    services: [
      { name: "Scalp Treatment", price: "₹800", duration: "30 min", description: "Deep cleansing and nourishing treatment" },
      { name: "Hair Spa", price: "₹1,200", duration: "45 min", description: "Intensive conditioning and repair" },
      { name: "Keratin Treatment", price: "₹4,000", duration: "150 min", description: "Smooth, frizz-free hair for months" },
      { name: "Anti-Dandruff Treatment", price: "₹600", duration: "30 min", description: "Specialized treatment for scalp health" },
    ],
  },
];

const Services = () => {
  const { ref, isVisible } = useScrollReveal();

  return (
    <Layout>
      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-charcoal">
        <div className="container mx-auto px-6 text-center">
          <span className="text-gold text-sm tracking-luxury uppercase mb-4 block">
            Our Services
          </span>
          <h1 className="heading-xl text-ivory mb-6">
            Crafted for <span className="text-gold-gradient">Excellence</span>
          </h1>
          <div className="decorative-line mx-auto mb-6" />
          <p className="text-ivory/60 max-w-2xl mx-auto">
            From classic cuts to complete transformations, every service at Mr Black Salon 
            is delivered with precision, care, and an unwavering commitment to quality.
          </p>
        </div>
      </section>

      {/* Services Grid */}
      <section ref={ref} className="section-padding bg-background">
        <div className="container mx-auto px-6">
          <div className="space-y-16">
            {serviceCategories.map((category, categoryIndex) => (
              <div
                key={category.title}
                className={`transition-all duration-700 ${
                  isVisible
                    ? "opacity-100 translate-y-0"
                    : "opacity-0 translate-y-8"
                }`}
                style={{ transitionDelay: `${categoryIndex * 100}ms` }}
              >
                {/* Category Header */}
                <div className="flex items-center gap-4 mb-8">
                  <div className="w-12 h-12 bg-charcoal flex items-center justify-center">
                    <category.icon className="w-6 h-6 text-gold" />
                  </div>
                  <h2 className="font-heading text-2xl md:text-3xl text-charcoal">
                    {category.title}
                  </h2>
                  <div className="flex-1 h-px bg-border" />
                </div>

                {/* Services List */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  {category.services.map((service) => (
                    <div
                      key={service.name}
                      className="group bg-card border border-border p-6 hover:border-gold/50 transition-all duration-300 card-hover"
                    >
                      <div className="flex justify-between items-start mb-2">
                        <h3 className="font-heading text-lg text-charcoal group-hover:text-gold transition-colors">
                          {service.name}
                        </h3>
                        <span className="font-heading text-xl text-gold">{service.price}</span>
                      </div>
                      <p className="text-muted-foreground text-sm mb-4">{service.description}</p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-muted-foreground text-xs">
                          <Clock className="w-4 h-4" />
                          {service.duration}
                        </div>
                        <Link
                          to={`/booking?service=${encodeURIComponent(service.name)}`}
                          className="text-gold text-sm font-medium hover:underline"
                        >
                          Book Now →
                        </Link>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-16 bg-charcoal text-center">
        <div className="container mx-auto px-6">
          <h2 className="heading-md text-ivory mb-4">Not Sure What You Need?</h2>
          <p className="text-ivory/60 mb-8 max-w-xl mx-auto">
            Book a consultation and let our experts recommend the perfect services for you.
          </p>
          <Link to="/booking" className="btn-gold inline-block">
            Book Consultation
          </Link>
        </div>
      </section>
    </Layout>
  );
};

export default Services;
