import Layout from "@/components/Layout";
import { useScrollReveal } from "@/hooks/useScrollReveal";
import { Phone, Mail, MapPin, Clock, MessageCircle, Instagram, Facebook } from "lucide-react";
import { Link } from "react-router-dom";

const Contact = () => {
  const { ref, isVisible } = useScrollReveal();

  return (
    <Layout>
      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-charcoal">
        <div className="container mx-auto px-6 text-center">
          <span className="text-gold text-sm tracking-luxury uppercase mb-4 block">
            Get In Touch
          </span>
          <h1 className="heading-xl text-ivory mb-6">
            Contact <span className="text-gold-gradient">Us</span>
          </h1>
          <div className="decorative-line mx-auto" />
        </div>
      </section>

      {/* Contact Content */}
      <section ref={ref} className="section-padding bg-background">
        <div className="container mx-auto px-6">
          <div
            className={`grid grid-cols-1 lg:grid-cols-2 gap-12 transition-all duration-700 ${
              isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
            }`}
          >
            {/* Contact Info */}
            <div>
              <h2 className="heading-md text-charcoal mb-8">Visit Our Salon</h2>
              
              <div className="space-y-8">
                {/* Address */}
                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-charcoal flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-5 h-5 text-gold" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg text-charcoal mb-1">Location</h3>
                    <p className="text-muted-foreground">
                      123 Premium Plaza, Anna Nagar<br />
                      Chennai, Tamil Nadu 600040
                    </p>
                    <a
                      href="https://maps.google.com"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-gold text-sm mt-2 inline-block hover:underline"
                    >
                      Get Directions →
                    </a>
                  </div>
                </div>

                {/* Phone */}
                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-charcoal flex items-center justify-center flex-shrink-0">
                    <Phone className="w-5 h-5 text-gold" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg text-charcoal mb-1">Phone</h3>
                    <a
                      href="tel:+919999999999"
                      className="text-muted-foreground hover:text-gold transition-colors"
                    >
                      +91 99999 99999
                    </a>
                    <p className="text-muted-foreground text-sm mt-1">
                      Call us for appointments or inquiries
                    </p>
                  </div>
                </div>

                {/* WhatsApp */}
                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-charcoal flex items-center justify-center flex-shrink-0">
                    <MessageCircle className="w-5 h-5 text-gold" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg text-charcoal mb-1">WhatsApp</h3>
                    <a
                      href="https://wa.me/919999999999"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-muted-foreground hover:text-gold transition-colors"
                    >
                      +91 99999 99999
                    </a>
                    <p className="text-muted-foreground text-sm mt-1">
                      Quick booking via WhatsApp
                    </p>
                  </div>
                </div>

                {/* Email */}
                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-charcoal flex items-center justify-center flex-shrink-0">
                    <Mail className="w-5 h-5 text-gold" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg text-charcoal mb-1">Email</h3>
                    <a
                      href="mailto:hello@mrblacksalon.com"
                      className="text-muted-foreground hover:text-gold transition-colors"
                    >
                      hello@mrblacksalon.com
                    </a>
                    <p className="text-muted-foreground text-sm mt-1">
                      For inquiries and collaborations
                    </p>
                  </div>
                </div>

                {/* Hours */}
                <div className="flex gap-4">
                  <div className="w-12 h-12 bg-charcoal flex items-center justify-center flex-shrink-0">
                    <Clock className="w-5 h-5 text-gold" />
                  </div>
                  <div>
                    <h3 className="font-heading text-lg text-charcoal mb-2">Business Hours</h3>
                    <ul className="space-y-1 text-muted-foreground text-sm">
                      <li className="flex justify-between max-w-[200px]">
                        <span>Mon - Fri</span>
                        <span>10:00 AM - 8:00 PM</span>
                      </li>
                      <li className="flex justify-between max-w-[200px]">
                        <span>Saturday</span>
                        <span>9:00 AM - 9:00 PM</span>
                      </li>
                      <li className="flex justify-between max-w-[200px]">
                        <span>Sunday</span>
                        <span>10:00 AM - 6:00 PM</span>
                      </li>
                    </ul>
                  </div>
                </div>

                {/* Social Links */}
                <div className="pt-4">
                  <h3 className="font-heading text-lg text-charcoal mb-4">Follow Us</h3>
                  <div className="flex gap-4">
                    <a
                      href="https://www.instagram.com/mr.black4473?igsh=dHdoMGloejJiZ2Ry"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-12 h-12 bg-charcoal flex items-center justify-center hover:bg-gold transition-colors group"
                      aria-label="Instagram"
                    >
                      <Instagram className="w-5 h-5 text-gold group-hover:text-charcoal" />
                    </a>
                    <a
                      href="https://facebook.com"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="w-12 h-12 bg-charcoal flex items-center justify-center hover:bg-gold transition-colors group"
                      aria-label="Facebook"
                    >
                      <Facebook className="w-5 h-5 text-gold group-hover:text-charcoal" />
                    </a>
                  </div>
                </div>
              </div>

              {/* Quick Book CTA */}
              <div className="mt-12 p-6 bg-charcoal">
                <h3 className="font-heading text-xl text-ivory mb-4">Ready to Book?</h3>
                <p className="text-ivory/70 text-sm mb-4">
                  Skip the call—book your appointment online in just a few clicks.
                </p>
                <Link to="/booking" className="btn-gold inline-block">
                  Book Appointment
                </Link>
              </div>
            </div>

            {/* Map */}
            <div className="h-[600px] lg:h-auto">
              <div className="w-full h-full bg-muted border border-border relative">
                {/* Placeholder for Google Map */}
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d124407.5761285658!2d80.14920744999999!3d13.047328500000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a5265ea4f7d3361%3A0x6e61a70b6863d433!2sChennai%2C%20Tamil%20Nadu!5e0!3m2!1sen!2sin!4v1699999999999!5m2!1sen!2sin"
                  width="100%"
                  height="100%"
                  style={{ border: 0 }}
                  allowFullScreen
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                  title="Mr Black Salon Location"
                  className="grayscale contrast-125"
                />
                {/* Gold overlay accent */}
                <div className="absolute top-0 left-0 w-full h-1 bg-gold" />
                <div className="absolute bottom-0 left-0 w-full h-1 bg-gold" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Quick Contact Card */}
      <section className="py-12 bg-charcoal">
        <div className="container mx-auto px-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-6">
            <div>
              <h3 className="font-heading text-xl text-ivory mb-2">
                Have Questions?
              </h3>
              <p className="text-ivory/60">
                We're here to help. Reach out anytime.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-4">
              <a
                href="tel:+919999999999"
                className="btn-gold inline-flex items-center justify-center gap-2"
              >
                <Phone className="w-4 h-4" />
                Call Now
              </a>
              <a
                href="https://wa.me/919894396201"
                target="_blank"
                rel="noopener noreferrer"
                className="btn-outline inline-flex items-center justify-center gap-2"
              >
                <MessageCircle className="w-4 h-4" />
                WhatsApp
              </a>
            </div>
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Contact;
