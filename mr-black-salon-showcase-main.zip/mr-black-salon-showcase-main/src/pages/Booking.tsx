import { useState, useEffect } from "react";
import Layout from "@/components/Layout";
import { useSearchParams } from "react-router-dom";
import { Calendar, Clock, User, Phone, MessageSquare, Check, Copy, MessageCircle, Mail } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

const services = [
  "Signature Haircut - ₹800",
  "Classic Haircut - ₹500",
  "Kids Haircut - ₹400",
  "Royal Shave - ₹600",
  "Beard Trim - ₹300",
  "Beard Sculpting - ₹500",
  "Executive Package - ₹2,500",
  "Groom's Package - ₹5,000",
  "Hair Color - ₹1,500+",
  "Hair Spa - ₹1,200",
  "Consultation - Free",
];

const timeSlots = [
  "10:00 AM", "10:30 AM", "11:00 AM", "11:30 AM",
  "12:00 PM", "12:30 PM", "2:00 PM", "2:30 PM",
  "3:00 PM", "3:30 PM", "4:00 PM", "4:30 PM",
  "5:00 PM", "5:30 PM", "6:00 PM", "6:30 PM",
  "7:00 PM", "7:30 PM",
];

interface BookingData {
  name: string;
  phone: string;
  service: string;
  date: string;
  time: string;
  notes: string;
}

const WHATSAPP_NUMBER = "919999999999";
const SALON_EMAIL = "bookings@mrblacksalon.com";

const Booking = () => {
  const [searchParams] = useSearchParams();
  const { toast } = useToast();
  const [showConfirmation, setShowConfirmation] = useState(false);
  const [formData, setFormData] = useState<BookingData>({
    name: "",
    phone: "",
    service: searchParams.get("service") || "",
    date: "",
    time: "",
    notes: "",
  });

  // Load saved bookings from localStorage
  const [savedBookings, setSavedBookings] = useState<BookingData[]>([]);

  useEffect(() => {
    const bookings = localStorage.getItem("mrblack_bookings");
    if (bookings) {
      setSavedBookings(JSON.parse(bookings));
    }
  }, []);

  const handleInputChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement | HTMLTextAreaElement>
  ) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const formatBookingMessage = () => {
    return `*New Booking Request - Mr Black Salon*
    
👤 Name: ${formData.name}
📞 Phone: ${formData.phone}
✂️ Service: ${formData.service}
📅 Date: ${formData.date}
🕐 Time: ${formData.time}
${formData.notes ? `📝 Notes: ${formData.notes}` : ""}

_Sent via Mr Black Salon Website_`;
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    // Validate
    if (!formData.name || !formData.phone || !formData.service || !formData.date || !formData.time) {
      toast({
        title: "Please fill all required fields",
        variant: "destructive",
      });
      return;
    }

    const message = formatBookingMessage();
    const encodedMessage = encodeURIComponent(message);

    // Save to localStorage
    const updatedBookings = [...savedBookings, { ...formData }];
    localStorage.setItem("mrblack_bookings", JSON.stringify(updatedBookings));
    setSavedBookings(updatedBookings);

    // Copy to clipboard
    navigator.clipboard.writeText(message.replace(/\*/g, "").replace(/_/g, ""));

    // Open WhatsApp
    window.open(`https://wa.me/${WHATSAPP_NUMBER}?text=${encodedMessage}`, "_blank");

    // Open email as fallback
    const emailSubject = encodeURIComponent("Booking Request - Mr Black Salon");
    const emailBody = encodeURIComponent(message.replace(/\*/g, "").replace(/_/g, ""));
    window.open(`mailto:${SALON_EMAIL}?subject=${emailSubject}&body=${emailBody}`, "_blank");

    // Show confirmation
    setShowConfirmation(true);
  };

  const getTomorrowDate = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    return tomorrow.toISOString().split("T")[0];
  };

  return (
    <Layout>
      {/* Hero Section */}
      <section className="pt-32 pb-16 bg-charcoal">
        <div className="container mx-auto px-6 text-center">
          <span className="text-gold text-sm tracking-luxury uppercase mb-4 block">
            Reserve Your Spot
          </span>
          <h1 className="heading-xl text-ivory mb-6">
            Book Your <span className="text-gold-gradient">Appointment</span>
          </h1>
          <div className="decorative-line mx-auto" />
        </div>
      </section>

      {/* Booking Form */}
      <section className="section-padding bg-background">
        <div className="container mx-auto px-6">
          <div className="max-w-2xl mx-auto">
            {showConfirmation ? (
              /* Confirmation Modal */
              <div className="bg-charcoal p-8 md:p-12 text-center animate-scale-in">
                <div className="w-20 h-20 bg-gold rounded-full flex items-center justify-center mx-auto mb-6">
                  <Check className="w-10 h-10 text-charcoal" />
                </div>
                <h2 className="font-heading text-2xl text-ivory mb-4">
                  Booking Prepared!
                </h2>
                <p className="text-ivory/70 mb-6">
                  Your booking details have been opened in WhatsApp and Email. 
                  Please send the message to confirm your appointment.
                </p>
                <div className="bg-charcoal/50 border border-gold/30 p-6 mb-6 text-left">
                  <div className="space-y-2 text-ivory/80 text-sm">
                    <p><strong className="text-gold">Name:</strong> {formData.name}</p>
                    <p><strong className="text-gold">Service:</strong> {formData.service}</p>
                    <p><strong className="text-gold">Date:</strong> {formData.date}</p>
                    <p><strong className="text-gold">Time:</strong> {formData.time}</p>
                  </div>
                </div>
                <div className="flex items-center justify-center gap-2 text-gold mb-6">
                  <Phone className="w-4 h-4" />
                  <span>Owner Contact: +91 99999 99999</span>
                </div>
                <div className="flex flex-col sm:flex-row gap-4 justify-center">
                  <a
                    href={`https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(formatBookingMessage())}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="btn-gold inline-flex items-center justify-center gap-2"
                  >
                    <MessageCircle className="w-4 h-4" />
                    Open WhatsApp
                  </a>
                  <button
                    onClick={() => setShowConfirmation(false)}
                    className="btn-outline"
                  >
                    Book Another
                  </button>
                </div>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                {/* Name Field */}
                <div>
                  <label className="flex items-center gap-2 text-charcoal font-medium mb-2">
                    <User className="w-4 h-4 text-gold" />
                    Your Name *
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 bg-background border border-border focus:border-gold focus:ring-1 focus:ring-gold outline-none transition-all"
                    placeholder="John Doe"
                    required
                  />
                </div>

                {/* Phone Field */}
                <div>
                  <label className="flex items-center gap-2 text-charcoal font-medium mb-2">
                    <Phone className="w-4 h-4 text-gold" />
                    Phone Number *
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 bg-background border border-border focus:border-gold focus:ring-1 focus:ring-gold outline-none transition-all"
                    placeholder="+91 98765 43210"
                    required
                  />
                </div>

                {/* Service Field */}
                <div>
                  <label className="flex items-center gap-2 text-charcoal font-medium mb-2">
                    <Calendar className="w-4 h-4 text-gold" />
                    Select Service *
                  </label>
                  <select
                    name="service"
                    value={formData.service}
                    onChange={handleInputChange}
                    className="w-full px-4 py-3 bg-background border border-border focus:border-gold focus:ring-1 focus:ring-gold outline-none transition-all"
                    required
                  >
                    <option value="">Choose a service...</option>
                    {services.map((service) => (
                      <option key={service} value={service}>
                        {service}
                      </option>
                    ))}
                  </select>
                </div>

                {/* Date & Time */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label className="flex items-center gap-2 text-charcoal font-medium mb-2">
                      <Calendar className="w-4 h-4 text-gold" />
                      Preferred Date *
                    </label>
                    <input
                      type="date"
                      name="date"
                      value={formData.date}
                      onChange={handleInputChange}
                      min={getTomorrowDate()}
                      className="w-full px-4 py-3 bg-background border border-border focus:border-gold focus:ring-1 focus:ring-gold outline-none transition-all"
                      required
                    />
                  </div>
                  <div>
                    <label className="flex items-center gap-2 text-charcoal font-medium mb-2">
                      <Clock className="w-4 h-4 text-gold" />
                      Preferred Time *
                    </label>
                    <select
                      name="time"
                      value={formData.time}
                      onChange={handleInputChange}
                      className="w-full px-4 py-3 bg-background border border-border focus:border-gold focus:ring-1 focus:ring-gold outline-none transition-all"
                      required
                    >
                      <option value="">Choose a time...</option>
                      {timeSlots.map((time) => (
                        <option key={time} value={time}>
                          {time}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Notes */}
                <div>
                  <label className="flex items-center gap-2 text-charcoal font-medium mb-2">
                    <MessageSquare className="w-4 h-4 text-gold" />
                    Additional Notes (Optional)
                  </label>
                  <textarea
                    name="notes"
                    value={formData.notes}
                    onChange={handleInputChange}
                    rows={4}
                    className="w-full px-4 py-3 bg-background border border-border focus:border-gold focus:ring-1 focus:ring-gold outline-none transition-all resize-none"
                    placeholder="Any special requests or preferences..."
                  />
                </div>

                {/* Submit Button */}
                <button type="submit" className="btn-gold w-full flex items-center justify-center gap-3">
                  <MessageCircle className="w-5 h-5" />
                  Book via WhatsApp
                </button>

                <p className="text-muted-foreground text-center text-sm">
                  Clicking the button will open WhatsApp and Email with your booking details.
                  <br />
                  Your booking will also be saved locally on this device.
                </p>
              </form>
            )}

            {/* Saved Bookings */}
            {savedBookings.length > 0 && !showConfirmation && (
              <div className="mt-12 pt-8 border-t border-border">
                <h3 className="font-heading text-xl text-charcoal mb-4">Your Recent Bookings</h3>
                <div className="space-y-4">
                  {savedBookings.slice(-3).reverse().map((booking, index) => (
                    <div
                      key={index}
                      className="bg-muted p-4 border border-border"
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-medium text-charcoal">{booking.service}</p>
                          <p className="text-muted-foreground text-sm">
                            {booking.date} at {booking.time}
                          </p>
                        </div>
                        <span className="text-gold text-xs">Pending</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      </section>
    </Layout>
  );
};

export default Booking;
