import { Link, useLocation } from "react-router-dom";
import { useState, useEffect } from "react";
import { Menu, X, Phone, Instagram, Facebook } from "lucide-react";

const navLinks = [
  { name: "Home", path: "/" },
  { name: "About", path: "/about" },
  { name: "Services", path: "/services" },
  { name: "Booking", path: "/booking" },
  { name: "Contact", path: "/contact" },
];

const Layout = ({ children }: { children: React.ReactNode }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  useEffect(() => {
    setIsMenuOpen(false);
  }, [location]);

  return (
    <div className="min-h-screen flex flex-col">
      {/* Header */}
      <header
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-500 ${
          isScrolled
            ? "bg-charcoal/95 backdrop-blur-md py-3 shadow-lg"
            : "bg-transparent py-6"
        }`}
      >
        <div className="container mx-auto px-6 flex items-center justify-between">
          {/* Logo */}
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 border-2 border-gold flex items-center justify-center">
              <span className="font-heading text-gold text-xl font-bold">M</span>
            </div>
            <div className="hidden sm:block">
              <span className="text-ivory font-heading text-lg tracking-luxury uppercase">
                Mr Black
              </span>
              <span className="block text-gold text-[10px] tracking-luxury uppercase -mt-1">
                Salon
              </span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <nav className="hidden lg:flex items-center gap-8">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`text-sm tracking-wider uppercase transition-all duration-300 gold-underline ${
                  location.pathname === link.path
                    ? "text-gold"
                    : "text-ivory/80 hover:text-gold"
                }`}
              >
                {link.name}
              </Link>
            ))}
          </nav>

          {/* CTA + Mobile Menu Toggle */}
          <div className="flex items-center gap-4">
            <Link
              to="/booking"
              className="hidden md:inline-block btn-gold text-xs py-3 px-6"
            >
              Book Now
            </Link>
            <button
              onClick={() => setIsMenuOpen(!isMenuOpen)}
              className="lg:hidden text-ivory p-2"
              aria-label="Toggle menu"
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        <div
          className={`lg:hidden absolute top-full left-0 right-0 bg-charcoal/98 backdrop-blur-md transition-all duration-500 ${
            isMenuOpen
              ? "opacity-100 translate-y-0"
              : "opacity-0 -translate-y-4 pointer-events-none"
          }`}
        >
          <nav className="container mx-auto px-6 py-8 flex flex-col gap-4">
            {navLinks.map((link) => (
              <Link
                key={link.path}
                to={link.path}
                className={`text-lg tracking-wider uppercase py-2 border-b border-ivory/10 transition-colors ${
                  location.pathname === link.path
                    ? "text-gold"
                    : "text-ivory/80 hover:text-gold"
                }`}
              >
                {link.name}
              </Link>
            ))}
            <Link
              to="/booking"
              className="btn-gold text-center mt-4"
            >
              Book Appointment
            </Link>
          </nav>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1">{children}</main>

      {/* Footer */}
      <footer className="bg-charcoal text-ivory py-16">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12 mb-12">
            {/* Brand */}
            <div>
              <div className="flex items-center gap-3 mb-6">
                <div className="w-12 h-12 border-2 border-gold flex items-center justify-center">
                  <span className="font-heading text-gold text-2xl font-bold">M</span>
                </div>
                <div>
                  <span className="text-ivory font-heading text-xl tracking-luxury uppercase">
                    Mr Black
                  </span>
                  <span className="block text-gold text-xs tracking-luxury uppercase -mt-1">
                    Salon
                  </span>
                </div>
              </div>
              <p className="text-ivory/60 text-sm leading-relaxed">
                Where precision meets artistry. Experience the finest in grooming and styling.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="font-heading text-lg mb-6 text-gold">Quick Links</h4>
              <ul className="space-y-3">
                {navLinks.map((link) => (
                  <li key={link.path}>
                    <Link
                      to={link.path}
                      className="text-ivory/60 hover:text-gold transition-colors text-sm"
                    >
                      {link.name}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>

            {/* Hours */}
            <div>
              <h4 className="font-heading text-lg mb-6 text-gold">Hours</h4>
              <ul className="space-y-2 text-sm text-ivory/60">
                <li className="flex justify-between">
                  <span>Mon - Fri</span>
                  <span>10:00 AM - 8:00 PM</span>
                </li>
                <li className="flex justify-between">
                  <span>Saturday</span>
                  <span>9:00 AM - 9:00 PM</span>
                </li>
                <li className="flex justify-between">
                  <span>Sunday</span>
                  <span>10:00 AM - 6:00 PM</span>
                </li>
              </ul>
            </div>

            {/* Contact */}
            <div>
              <h4 className="font-heading text-lg mb-6 text-gold">Contact</h4>
              <ul className="space-y-3 text-sm text-ivory/60">
                <li>
                  <a
                    href="tel:+919999999999"
                    className="flex items-center gap-2 hover:text-gold transition-colors"
                  >
                    <Phone size={16} />
                    +91 99999 99999
                  </a>
                </li>
                <li>Chennai, Tamil Nadu</li>
              </ul>
              <div className="flex gap-4 mt-6">
                <a
                  href="https://instagram.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 border border-ivory/20 flex items-center justify-center hover:border-gold hover:text-gold transition-all"
                  aria-label="Instagram"
                >
                  <Instagram size={18} />
                </a>
                <a
                  href="https://facebook.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="w-10 h-10 border border-ivory/20 flex items-center justify-center hover:border-gold hover:text-gold transition-all"
                  aria-label="Facebook"
                >
                  <Facebook size={18} />
                </a>
              </div>
            </div>
          </div>

          {/* Divider */}
          <div className="border-t border-ivory/10 pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center gap-4">
              <p className="text-ivory/40 text-xs">
                © {new Date().getFullYear()} Mr Black Salon. All rights reserved.
              </p>
              <div className="flex gap-6 text-xs text-ivory/40">
                <a href="#" className="hover:text-gold transition-colors">
                  Privacy Policy
                </a>
                <a href="#" className="hover:text-gold transition-colors">
                  Terms of Service
                </a>
              </div>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;
