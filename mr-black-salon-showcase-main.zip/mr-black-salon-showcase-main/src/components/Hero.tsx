import { Link } from "react-router-dom";
import { useEffect, useState } from "react";
import heroImage from "@/assets/hero-barbershop.jpg";

const Hero = () => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    setIsVisible(true);
  }, []);

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Parallax Effect */}
      <div 
        className="absolute inset-0 bg-cover bg-center bg-no-repeat"
        style={{ backgroundImage: `url(${heroImage})` }}
      >
        <div className="absolute inset-0 bg-hero-overlay" />
      </div>

      {/* Decorative Gold Lines */}
      <div className="absolute top-0 left-0 w-full h-1 bg-gold-gradient opacity-60" />
      <div className="absolute bottom-0 left-0 w-full h-1 bg-gold-gradient opacity-60" />

      {/* Content */}
      <div className="relative z-10 container mx-auto px-6 text-center">
        {/* Animated Badge */}
        <div
          className={`inline-flex items-center gap-3 mb-8 transition-all duration-1000 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <span className="w-12 h-px bg-gold" />
          <span className="text-gold text-sm tracking-luxury uppercase font-medium">
            Est. 2020 • Chennai
          </span>
          <span className="w-12 h-px bg-gold" />
        </div>

        {/* Main Heading */}
        <h1
          className={`font-heading text-ivory heading-xl mb-6 transition-all duration-1000 delay-200 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          The Art of
          <span className="block text-gold-gradient mt-2">Distinction</span>
        </h1>

        {/* Subtitle */}
        <p
          className={`text-ivory/70 text-lg md:text-xl max-w-2xl mx-auto mb-10 font-light transition-all duration-1000 delay-400 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          Where precision craftsmanship meets timeless elegance. 
          Experience grooming redefined at Mr Black Salon.
        </p>

        {/* CTA Buttons */}
        <div
          className={`flex flex-col sm:flex-row items-center justify-center gap-4 transition-all duration-1000 delay-500 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <Link to="/booking" className="btn-gold min-w-[200px]">
            Book Appointment
          </Link>
          <Link to="/services" className="btn-outline min-w-[200px]">
            Our Services
          </Link>
        </div>

        {/* Scroll Indicator */}
        <div
          className={`absolute bottom-12 left-1/2 -translate-x-1/2 transition-all duration-1000 delay-700 ${
            isVisible ? "opacity-100" : "opacity-0"
          }`}
        >
          <div className="flex flex-col items-center gap-2 animate-float">
            <span className="text-ivory/50 text-xs tracking-wider uppercase">Scroll</span>
            <div className="w-px h-12 bg-gradient-to-b from-gold to-transparent" />
          </div>
        </div>
      </div>

      {/* Side Decorations */}
      <div className="absolute left-8 top-1/2 -translate-y-1/2 hidden xl:flex flex-col items-center gap-4">
        <div className="w-px h-24 bg-gold/30" />
        <span className="text-gold text-xs tracking-wider -rotate-90 whitespace-nowrap">
          Premium Grooming
        </span>
        <div className="w-px h-24 bg-gold/30" />
      </div>
    </section>
  );
};

export default Hero;
