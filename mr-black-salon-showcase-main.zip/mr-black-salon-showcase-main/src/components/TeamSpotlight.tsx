import { Instagram, Linkedin } from "lucide-react";
import { useScrollReveal } from "@/hooks/useScrollReveal";
import stylist1 from "@/assets/stylist-1.jpg";
import stylist2 from "@/assets/stylist-2.jpg";
import stylist3 from "@/assets/stylist-3.jpg";

const team = [
  {
    name: "Arun Krishnan",
    role: "Master Barber",
    expertise: "Classic Cuts • Beard Sculpting",
    image: stylist1,
    instagram: "#",
    linkedin: "#",
  },
  {
    name: "Priya Sharma",
    role: "Senior Stylist",
    expertise: "Color Expert • Transformations",
    image: stylist2,
    instagram: "#",
    linkedin: "#",
  },
  {
    name: "Rohit Nair",
    role: "Creative Director",
    expertise: "Modern Fades • Editorial Looks",
    image: stylist3,
    instagram: "#",
    linkedin: "#",
  },
];

const TeamSpotlight = () => {
  const { ref, isVisible } = useScrollReveal();

  return (
    <section ref={ref} className="section-padding bg-charcoal">
      <div className="container mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-gold text-sm tracking-luxury uppercase mb-4 block">
            Meet The Artists
          </span>
          <h2 className="heading-lg text-ivory mb-4">Our Expert Team</h2>
          <div className="decorative-line mx-auto" />
        </div>

        {/* Team Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {team.map((member, index) => (
            <div
              key={member.name}
              className={`group relative overflow-hidden transition-all duration-700 ${
                isVisible
                  ? "opacity-100 translate-y-0"
                  : "opacity-0 translate-y-8"
              }`}
              style={{ transitionDelay: `${index * 150}ms` }}
            >
              {/* Image Container */}
              <div className="relative aspect-[3/4] overflow-hidden">
                <img
                  src={member.image}
                  alt={member.name}
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />

                {/* Gradient Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-charcoal via-transparent to-transparent opacity-90" />

                {/* Hover Overlay */}
                <div className="absolute inset-0 bg-charcoal/80 opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-center justify-center">
                  <div className="text-center p-6 transform translate-y-4 group-hover:translate-y-0 transition-transform duration-500">
                    <p className="text-gold text-sm tracking-wider uppercase mb-4">
                      {member.expertise}
                    </p>
                    <div className="flex justify-center gap-4">
                      <a
                        href={member.instagram}
                        className="w-10 h-10 border border-gold flex items-center justify-center hover:bg-gold transition-colors group/icon"
                        aria-label={`${member.name}'s Instagram`}
                      >
                        <Instagram className="w-4 h-4 text-gold group-hover/icon:text-charcoal" />
                      </a>
                      <a
                        href={member.linkedin}
                        className="w-10 h-10 border border-gold flex items-center justify-center hover:bg-gold transition-colors group/icon"
                        aria-label={`${member.name}'s LinkedIn`}
                      >
                        <Linkedin className="w-4 h-4 text-gold group-hover/icon:text-charcoal" />
                      </a>
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="absolute bottom-0 left-0 right-0 p-6">
                  <h3 className="font-heading text-xl text-ivory mb-1">
                    {member.name}
                  </h3>
                  <p className="text-gold text-sm tracking-wider uppercase">
                    {member.role}
                  </p>
                </div>

                {/* Gold border accent */}
                <div className="absolute bottom-0 left-0 w-full h-1 bg-gold transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left" />
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default TeamSpotlight;
