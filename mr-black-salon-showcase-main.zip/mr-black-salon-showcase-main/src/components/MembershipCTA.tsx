import { Link } from "react-router-dom";
import { Gift, Crown } from "lucide-react";
import { useScrollReveal } from "@/hooks/useScrollReveal";

const MembershipCTA = () => {
  const { ref, isVisible } = useScrollReveal();

  return (
    <section ref={ref} className="section-padding bg-background">
      <div className="container mx-auto px-6">
        <div
          className={`grid grid-cols-1 lg:grid-cols-2 gap-8 transition-all duration-700 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          {/* Membership Card */}
          <div className="relative bg-charcoal p-8 md:p-12 overflow-hidden group">
            {/* Background Pattern */}
            <div className="absolute inset-0 opacity-10">
              <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                <pattern id="grid" width="10" height="10" patternUnits="userSpaceOnUse">
                  <path d="M 10 0 L 0 0 0 10" fill="none" stroke="hsl(var(--gold))" strokeWidth="0.5" />
                </pattern>
                <rect width="100" height="100" fill="url(#grid)" />
              </svg>
            </div>

            <div className="relative z-10">
              <div className="inline-flex items-center justify-center w-16 h-16 border border-gold mb-6">
                <Crown className="w-8 h-8 text-gold" />
              </div>
              <h3 className="font-heading text-2xl md:text-3xl text-ivory mb-4">
                Black Card Membership
              </h3>
              <p className="text-ivory/60 mb-6 leading-relaxed">
                Join the elite. Enjoy priority bookings, exclusive discounts, complimentary drinks, 
                and member-only events throughout the year.
              </p>
              <ul className="space-y-2 mb-8">
                {["15% off all services", "Priority booking", "Complimentary beverages", "Exclusive events"].map(
                  (benefit) => (
                    <li key={benefit} className="flex items-center gap-3 text-ivory/80 text-sm">
                      <span className="w-1.5 h-1.5 bg-gold rounded-full" />
                      {benefit}
                    </li>
                  )
                )}
              </ul>
              <Link to="/contact" className="btn-gold inline-block">
                Inquire Now
              </Link>
            </div>

            {/* Decorative corner */}
            <div className="absolute top-0 right-0 w-24 h-24 border-t-2 border-r-2 border-gold opacity-30" />
          </div>

          {/* Gift Card */}
          <div className="relative bg-gold p-8 md:p-12 overflow-hidden group">
            {/* Background Pattern */}
            <div className="absolute inset-0 opacity-10">
              <svg className="w-full h-full" viewBox="0 0 100 100" preserveAspectRatio="none">
                <pattern id="diamonds" width="20" height="20" patternUnits="userSpaceOnUse">
                  <polygon points="10,0 20,10 10,20 0,10" fill="none" stroke="hsl(var(--charcoal))" strokeWidth="0.5" />
                </pattern>
                <rect width="100" height="100" fill="url(#diamonds)" />
              </svg>
            </div>

            <div className="relative z-10">
              <div className="inline-flex items-center justify-center w-16 h-16 border border-charcoal mb-6">
                <Gift className="w-8 h-8 text-charcoal" />
              </div>
              <h3 className="font-heading text-2xl md:text-3xl text-charcoal mb-4">
                Gift the Experience
              </h3>
              <p className="text-charcoal/70 mb-6 leading-relaxed">
                Give the gift of luxury grooming. Our elegantly packaged gift vouchers are perfect for 
                birthdays, anniversaries, or celebrating someone special.
              </p>
              <ul className="space-y-2 mb-8">
                {["Custom amounts available", "Beautiful presentation box", "Valid for 1 year", "Redeemable on all services"].map(
                  (benefit) => (
                    <li key={benefit} className="flex items-center gap-3 text-charcoal/80 text-sm">
                      <span className="w-1.5 h-1.5 bg-charcoal rounded-full" />
                      {benefit}
                    </li>
                  )
                )}
              </ul>
              <Link to="/contact" className="btn-primary inline-block">
                Purchase Gift Card
              </Link>
            </div>

            {/* Decorative corner */}
            <div className="absolute bottom-0 left-0 w-24 h-24 border-b-2 border-l-2 border-charcoal opacity-30" />
          </div>
        </div>
      </div>
    </section>
  );
};

export default MembershipCTA;
