import { useState, useRef, useEffect } from "react";
import { useScrollReveal } from "@/hooks/useScrollReveal";
import beforeImage from "@/assets/before-haircut.jpg";
import afterImage from "@/assets/after-haircut.jpg";

const BeforeAfterSlider = () => {
  const [sliderPosition, setSliderPosition] = useState(50);
  const [isDragging, setIsDragging] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const { ref, isVisible } = useScrollReveal();

  const handleMove = (clientX: number) => {
    if (!containerRef.current || !isDragging) return;

    const rect = containerRef.current.getBoundingClientRect();
    const x = clientX - rect.left;
    const percentage = (x / rect.width) * 100;
    setSliderPosition(Math.min(Math.max(percentage, 0), 100));
  };

  const handleMouseMove = (e: MouseEvent) => handleMove(e.clientX);
  const handleTouchMove = (e: TouchEvent) => handleMove(e.touches[0].clientX);

  const handleEnd = () => setIsDragging(false);

  useEffect(() => {
    if (isDragging) {
      window.addEventListener("mousemove", handleMouseMove);
      window.addEventListener("mouseup", handleEnd);
      window.addEventListener("touchmove", handleTouchMove);
      window.addEventListener("touchend", handleEnd);
    }

    return () => {
      window.removeEventListener("mousemove", handleMouseMove);
      window.removeEventListener("mouseup", handleEnd);
      window.removeEventListener("touchmove", handleTouchMove);
      window.removeEventListener("touchend", handleEnd);
    };
  }, [isDragging]);

  return (
    <section ref={ref} className="section-padding bg-charcoal">
      <div className="container mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-12">
          <span className="text-gold text-sm tracking-luxury uppercase mb-4 block">
            Transformations
          </span>
          <h2 className="heading-lg text-ivory mb-4">Before & After</h2>
          <div className="decorative-line mx-auto mb-6" />
          <p className="text-ivory/60 max-w-xl mx-auto">
            Witness the artistry of our master stylists. Drag the slider to reveal the transformation.
          </p>
        </div>

        {/* Slider Container */}
        <div
          ref={containerRef}
          className={`relative max-w-3xl mx-auto aspect-[4/5] md:aspect-[3/4] cursor-ew-resize overflow-hidden transition-all duration-700 ${
            isVisible ? "opacity-100 scale-100" : "opacity-0 scale-95"
          }`}
          onMouseDown={() => setIsDragging(true)}
          onTouchStart={() => setIsDragging(true)}
        >
          {/* After Image (Background) */}
          <div className="absolute inset-0">
            <img
              src={afterImage}
              alt="After transformation"
              className="w-full h-full object-cover"
            />
            <span className="absolute bottom-4 right-4 bg-gold text-charcoal px-4 py-2 text-sm font-semibold tracking-wider uppercase">
              After
            </span>
          </div>

          {/* Before Image (Clipped) */}
          <div
            className="absolute inset-0 overflow-hidden"
            style={{ clipPath: `inset(0 ${100 - sliderPosition}% 0 0)` }}
          >
            <img
              src={beforeImage}
              alt="Before transformation"
              className="w-full h-full object-cover"
            />
            <span className="absolute bottom-4 left-4 bg-charcoal text-ivory px-4 py-2 text-sm font-semibold tracking-wider uppercase border border-gold">
              Before
            </span>
          </div>

          {/* Slider Handle */}
          <div
            className="absolute top-0 bottom-0 w-1 bg-gold cursor-ew-resize"
            style={{ left: `${sliderPosition}%` }}
          >
            <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-12 h-12 bg-gold rounded-full flex items-center justify-center shadow-lg">
              <svg
                className="w-6 h-6 text-charcoal"
                fill="none"
                viewBox="0 0 24 24"
                stroke="currentColor"
              >
                <path
                  strokeLinecap="round"
                  strokeLinejoin="round"
                  strokeWidth={2}
                  d="M8 9l4-4 4 4m0 6l-4 4-4-4"
                />
              </svg>
            </div>
          </div>

          {/* Border */}
          <div className="absolute inset-0 border-2 border-gold/30 pointer-events-none" />
        </div>
      </div>
    </section>
  );
};

export default BeforeAfterSlider;
