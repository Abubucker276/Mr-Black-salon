import { useState, useEffect } from "react";
import { Star, ChevronLeft, ChevronRight, Quote } from "lucide-react";
import { useScrollReveal } from "@/hooks/useScrollReveal";

const testimonials = [
  {
    name: "Rajesh Kumar",
    role: "Business Executive",
    content:
      "Mr Black Salon has completely transformed my grooming routine. The attention to detail is unmatched. Every visit feels like a luxury experience.",
    rating: 5,
  },
  {
    name: "Arjun Menon",
    role: "Tech Entrepreneur",
    content:
      "I've been to salons across the world, and Mr Black stands out. The ambiance, the skill, the service — everything is world-class.",
    rating: 5,
  },
  {
    name: "Vikram Singh",
    role: "Film Director",
    content:
      "The team here understands style. They don't just cut hair; they craft an image. Highly recommend the Executive Package.",
    rating: 5,
  },
  {
    name: "Karthik Rajan",
    role: "Lawyer",
    content:
      "Professional, punctual, and premium. Mr Black Salon is my go-to for looking sharp before any important meeting or court appearance.",
    rating: 5,
  },
];

const Testimonials = () => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isAnimating, setIsAnimating] = useState(false);
  const { ref, isVisible } = useScrollReveal();

  const goToSlide = (index: number) => {
    if (isAnimating) return;
    setIsAnimating(true);
    setCurrentIndex(index);
    setTimeout(() => setIsAnimating(false), 500);
  };

  const nextSlide = () => {
    goToSlide((currentIndex + 1) % testimonials.length);
  };

  const prevSlide = () => {
    goToSlide((currentIndex - 1 + testimonials.length) % testimonials.length);
  };

  useEffect(() => {
    const interval = setInterval(nextSlide, 6000);
    return () => clearInterval(interval);
  }, [currentIndex]);

  return (
    <section ref={ref} className="section-padding bg-background relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div
          className="absolute inset-0"
          style={{
            backgroundImage: `repeating-linear-gradient(45deg, transparent, transparent 35px, hsl(var(--gold)) 35px, hsl(var(--gold)) 70px)`,
          }}
        />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-gold text-sm tracking-luxury uppercase mb-4 block">
            Testimonials
          </span>
          <h2 className="heading-lg text-charcoal mb-4">What Our Clients Say</h2>
          <div className="decorative-line mx-auto" />
        </div>

        {/* Testimonial Carousel */}
        <div
          className={`max-w-4xl mx-auto transition-all duration-700 ${
            isVisible ? "opacity-100 translate-y-0" : "opacity-0 translate-y-8"
          }`}
        >
          <div className="relative">
            {/* Quote Icon */}
            <Quote className="absolute -top-8 left-0 w-16 h-16 text-gold/20" />

            {/* Testimonial Content */}
            <div className="bg-charcoal p-8 md:p-12 relative">
              <div
                className={`transition-all duration-500 ${
                  isAnimating ? "opacity-0 translate-x-4" : "opacity-100 translate-x-0"
                }`}
              >
                {/* Stars */}
                <div className="flex gap-1 mb-6">
                  {[...Array(testimonials[currentIndex].rating)].map((_, i) => (
                    <Star
                      key={i}
                      className="w-5 h-5 text-gold fill-gold"
                      style={{ animationDelay: `${i * 100}ms` }}
                    />
                  ))}
                </div>

                {/* Quote */}
                <p className="text-ivory/90 text-lg md:text-xl leading-relaxed mb-8 font-light italic">
                  "{testimonials[currentIndex].content}"
                </p>

                {/* Author */}
                <div>
                  <p className="font-heading text-gold text-lg">
                    {testimonials[currentIndex].name}
                  </p>
                  <p className="text-ivory/50 text-sm">
                    {testimonials[currentIndex].role}
                  </p>
                </div>
              </div>

              {/* Navigation Arrows */}
              <div className="absolute top-1/2 -translate-y-1/2 left-0 right-0 flex justify-between pointer-events-none px-4 md:-mx-6">
                <button
                  onClick={prevSlide}
                  className="pointer-events-auto w-12 h-12 bg-background border border-gold flex items-center justify-center hover:bg-gold hover:text-charcoal transition-all group"
                  aria-label="Previous testimonial"
                >
                  <ChevronLeft className="w-5 h-5 text-gold group-hover:text-charcoal" />
                </button>
                <button
                  onClick={nextSlide}
                  className="pointer-events-auto w-12 h-12 bg-background border border-gold flex items-center justify-center hover:bg-gold hover:text-charcoal transition-all group"
                  aria-label="Next testimonial"
                >
                  <ChevronRight className="w-5 h-5 text-gold group-hover:text-charcoal" />
                </button>
              </div>
            </div>

            {/* Dots */}
            <div className="flex justify-center gap-3 mt-8">
              {testimonials.map((_, index) => (
                <button
                  key={index}
                  onClick={() => goToSlide(index)}
                  className={`w-2 h-2 rounded-full transition-all duration-300 ${
                    index === currentIndex
                      ? "w-8 bg-gold"
                      : "bg-charcoal/30 hover:bg-gold/50"
                  }`}
                  aria-label={`Go to testimonial ${index + 1}`}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Testimonials;
