import { Scissors, Sparkles, Crown } from "lucide-react";
import { Link } from "react-router-dom";
import { useScrollReveal } from "@/hooks/useScrollReveal";

const services = [
  {
    icon: Scissors,
    title: "Precision Haircut",
    description:
      "Masterfully crafted cuts tailored to your unique style and face shape. Every snip is deliberate, every line immaculate.",
    price: "₹800",
  },
  {
    icon: Crown,
    title: "Royal Shave",
    description:
      "The ultimate hot towel shave experience. Premium oils, warm lather, and a finish so smooth you'll feel like royalty.",
    price: "₹600",
  },
  {
    icon: Sparkles,
    title: "Executive Package",
    description:
      "Our signature 90-minute grooming ritual. Haircut, beard sculpting, facial, and scalp massage for the distinguished gentleman.",
    price: "₹2,500",
  },
];

const SignatureServices = () => {
  const { ref, isVisible } = useScrollReveal();

  return (
    <section ref={ref} className="section-padding bg-background">
      <div className="container mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-16">
          <span className="text-gold text-sm tracking-luxury uppercase mb-4 block">
            Our Expertise
          </span>
          <h2 className="heading-lg text-charcoal mb-4">Signature Services</h2>
          <div className="decorative-line mx-auto" />
        </div>

        {/* Services Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 lg:gap-12">
          {services.map((service, index) => (
            <div
              key={service.title}
              className={`group relative bg-charcoal p-8 lg:p-10 text-center card-hover transition-all duration-700 ${
                isVisible
                  ? "opacity-100 translate-y-0"
                  : "opacity-0 translate-y-8"
              }`}
              style={{ transitionDelay: `${index * 150}ms` }}
            >
              {/* Gold corner accent */}
              <div className="absolute top-0 left-0 w-16 h-16 border-t-2 border-l-2 border-gold opacity-50" />
              <div className="absolute bottom-0 right-0 w-16 h-16 border-b-2 border-r-2 border-gold opacity-50" />

              {/* Icon */}
              <div className="inline-flex items-center justify-center w-16 h-16 border border-gold mb-6 group-hover:bg-gold transition-colors duration-300">
                <service.icon className="w-7 h-7 text-gold group-hover:text-charcoal transition-colors duration-300" />
              </div>

              {/* Content */}
              <h3 className="font-heading text-xl text-ivory mb-4">
                {service.title}
              </h3>
              <p className="text-ivory/60 text-sm leading-relaxed mb-6">
                {service.description}
              </p>

              {/* Price */}
              <span className="text-gold font-heading text-2xl">
                {service.price}
              </span>
            </div>
          ))}
        </div>

        {/* CTA */}
        <div className="text-center mt-12">
          <Link to="/services" className="btn-primary">
            View All Services
          </Link>
        </div>
      </div>
    </section>
  );
};

export default SignatureServices;
